from telegram.ext import Updater, MessageHandler, Filters
import logging
import requests
import json

# Konfigurasi
TOKEN = "7271061207:AAGwGMVgxHkFrQVJg9hMVnwR3fSiLdJ8Pj8"
API_KEY = "ihkaz170921"

# Setup logging
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                   level=logging.INFO)
logger = logging.getLogger(__name__)

def handle_message(update, context):
    user_id = str(update.effective_user.id)
    question = update.message.text
    
    # Mengirim indikator "sedang mengetik"
    context.bot.send_chat_action(update.effective_chat.id, 'typing')
    
    try:
        # Request ke API
        url = "https://api.neoxr.eu/api/gpt4-session"
        params = {
            'q': question,
            'session': user_id,
            'apikey': API_KEY
        }
        
        response = requests.get(url, params=params)
        
        if response.status_code == 200:
            data = response.json()
            
            # Cek status response
            if data.get('status') == True and 'data' in data and 'message' in data['data']:
                answer = data['data']['message']
                update.message.reply_text(answer)
            else:
                logger.error(f"Invalid response format or status: {data}")
                update.message.reply_text("Maaf, saya tidak bisa memproses permintaan Anda saat ini.")
        else:
            logger.error(f"API error: {response.status_code}")
            update.message.reply_text("Maaf, terjadi kesalahan saat memproses permintaan Anda.")
            
    except Exception as e:
        logger.error(f"Error: {str(e)}")
        update.message.reply_text("Maaf, terjadi kesalahan. Silakan coba lagi nanti.")

def main():
    # Inisialisasi bot
    updater = Updater(TOKEN, use_context=True)
    dp = updater.dispatcher
    
    # Handler untuk semua pesan teks
    dp.add_handler(MessageHandler(Filters.text & ~Filters.command, handle_message))
    
    # Mulai bot
    updater.start_polling()
    updater.idle()

if __name__ == '__main__':
    main()
